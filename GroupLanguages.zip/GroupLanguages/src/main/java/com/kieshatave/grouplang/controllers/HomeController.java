package com.kieshatave.grouplang.controllers;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kieshatave.grouplang.models.Language;

@SpringBootApplication
@Controller
public class HomeController {
	
}
